# HW3: Scene in 3D

Name:  Ryo Suzuki
ID:    rysu7393
Email: ryo.suzuki@colorado.edu


## Compile and execute
```
$ make
$ ./hw3
```

## Command

There are some key commands to interact with the program.

* Cursor : Up, Down, Right, Left axes
* a / A  : Show/Hide axes
* x      : Show from X axis
* y      : Show from Y axis
* z      : Show from Z axis
* Esc    : Exit the program

This assignment took me 9 hours to complete.